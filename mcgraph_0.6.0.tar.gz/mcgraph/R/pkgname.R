#' @details
#' The only function you're likely to need from cat is [cat()].
#' Otherwise refer to the vignettes to see how to format the documentation.
#' @import Rcpp
#' @useDynLib mcgraph , .registration = TRUE
#' @keywords internal
"_PACKAGE"
#> [1] "_PACKAGE"
